from optimal_solver import get_optimal_moves
from hanoi_exceptions import IllegalMoveError, SuboptimalMoveError, PuzzleNotCompletedError

class TowerOfHanoi:
    def __init__(self, num_disks):
        if num_disks < 1:
            raise ValueError("Number of disks must be at least 1.")
        self.num_disks = num_disks
        self.pegs = {0: list(range(num_disks, 0, -1)), 1: [], 2: []} # Disks are represented by their size, largest first
        self.move_listeners = []
        self.optimal_moves = get_optimal_moves(num_disks, 0, 2, 1)
        self.current_optimal_move_index = 0

    def add_move_listener(self, callback):
        self.move_listeners.append(callback)

    def _notify_move_listeners(self, source_peg, destination_peg):
        for callback in self.move_listeners:
            callback(source_peg, destination_peg)

    def get_state(self):
        return {peg_id: list(disks) for peg_id, disks in self.pegs.items()}

    def is_solved(self):
        """Checks if the puzzle is solved (all disks on the destination peg)."""
        return len(self.pegs[2]) == self.num_disks

    def _check_legal_move(self, source_peg, destination_peg):
        move_str = f"Tried to move from peg {source_peg} to peg {destination_peg}. "
        if not (0 <= source_peg < 3 and 0 <= destination_peg < 3):
            raise IllegalMoveError(move_str + "Invalid peg index.")
        if source_peg == destination_peg:
            raise IllegalMoveError(move_str + "Source and destination pegs cannot be the same.")
        if not self.pegs[source_peg]:
            raise IllegalMoveError(move_str + "Source peg is empty.")

        disk_to_move = self.pegs[source_peg][-1]
        if self.pegs[destination_peg] and disk_to_move > self.pegs[destination_peg][-1]:
            raise IllegalMoveError(move_str + f"Cannot place disk {disk_to_move} on a smaller disk {self.pegs[destination_peg][-1]}.")
        return True

    def move_disk(self, source_peg, destination_peg):
        # First, check if the move is legal according to Tower of Hanoi rules
        self._check_legal_move(source_peg, destination_peg)

        # If the move is legal, then check for optimality
        if self.current_optimal_move_index >= len(self.optimal_moves):
            raise SuboptimalMoveError("No more optimal moves expected. Puzzle already solved optimally or an error occurred.")

        expected_move = self.optimal_moves[self.current_optimal_move_index]
        if (source_peg, destination_peg) != expected_move:
            raise SuboptimalMoveError(f"Tried to move from peg {source_peg} to peg {destination_peg}. Suboptimal move: Expected {expected_move}, but got ({source_peg}, {destination_peg}).")

        # If both legal and optimal, perform the move
        disk = self.pegs[source_peg].pop()
        self.pegs[destination_peg].append(disk)
        self.current_optimal_move_index += 1
        self._notify_move_listeners(source_peg, destination_peg)
        return True


