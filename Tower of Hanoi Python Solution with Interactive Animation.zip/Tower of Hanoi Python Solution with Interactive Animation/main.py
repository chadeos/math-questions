from hanoi_game import TowerOfHanoi
from hanoi_gui import HanoiGUI
from hanoi_solver import solve_hanoi
from hanoi_exceptions import HanoiError, IllegalMoveError, SuboptimalMoveError, PuzzleNotCompletedError
import tkinter as tk

NUM_DISKS = 5 # You can change this to test with more disks

def main():
    game = TowerOfHanoi(NUM_DISKS)
    gui = HanoiGUI(game, NUM_DISKS)

    # Register the GUI's on_game_move as a listener for game logic moves
    game.add_move_listener(gui.on_game_move)

    # Define the callback for the solver
    def solver_move_callback(source_peg, destination_peg):
        try:
            game.move_disk(source_peg, destination_peg)
            gui.display_error("") # Clear any previous error message
        except (IllegalMoveError, SuboptimalMoveError) as e:
            gui.display_error(str(e))
            # If an illegal or suboptimal move is attempted, stop the solver
            raise e # Re-raise the exception to stop the solver
        finally:
            gui.update_idletasks() # Update GUI after each move
            gui.update() # Process events to keep GUI responsive

    def run_solver():
        try:
            solve_hanoi(NUM_DISKS, 0, 2, 1, solver_move_callback)
            # After solver finishes, check if the puzzle is actually solved
            if not game.is_solved():
                raise PuzzleNotCompletedError("Solver finished, but the puzzle is not completed.")
        except HanoiError as e:
            gui.display_error(str(e))
        except Exception as e:
            gui.display_error(f"An unexpected error occurred: {e}")

    # Start the GUI in a separate thread or after a delay to allow it to initialize
    gui.set_solver_start_callback(run_solver)

    gui.run()

if __name__ == "__main__":
    main()


