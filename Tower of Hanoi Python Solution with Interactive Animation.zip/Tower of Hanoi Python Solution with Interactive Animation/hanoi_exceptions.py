class HanoiError(Exception):
    """Base exception for Tower of Hanoi game errors."""
    pass

class IllegalMoveError(HanoiError):
    """Raised when an illegal move is attempted."""
    pass

class SuboptimalMoveError(HanoiError):
    """Raised when a suboptimal move is attempted."""
    pass

class PuzzleNotCompletedError(HanoiError):
    """Raised when the puzzle is not completed after the solver finishes."""
    pass


