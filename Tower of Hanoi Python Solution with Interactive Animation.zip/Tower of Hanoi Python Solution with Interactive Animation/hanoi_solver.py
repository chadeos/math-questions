def solve_hanoi(n, source, destination, auxiliary, move_callback):
    move_callback(source, destination)


