import tkinter as tk
import time

class HanoiGUI(tk.Tk):
    def __init__(self, game_logic, num_disks):
        super().__init__()
        self.game_logic = game_logic
        self.num_disks = num_disks
        self.title("Tower of Hanoi")
        self.geometry("800x600")
        self.canvas = tk.Canvas(self, width=800, height=500, bg="lightgray")
        self.canvas.pack()

        self.peg_coords = {
            0: (150, 450), # x, y for base of peg 0
            1: (400, 450), # x, y for base of peg 1
            2: (650, 450)  # x, y for base of peg 2
        }
        self.disk_height = 20
        self.disk_width_unit = 30 # Smallest disk width
        self.disks = {} # Stores disk_size: (rectangle_id, text_id)
        self.draw_pegs()
        self.draw_initial_disks()

        self.error_label = tk.Label(self, text="", fg="red", font=("Arial", 14))
        self.error_label.pack()

        self.start_button = tk.Button(self, text="Start Solver", command=self.start_solver)
        self.start_button.pack()

        self.solver_start_callback = None

    def set_solver_start_callback(self, callback):
        self.solver_start_callback = callback

    def start_solver(self):
        if self.solver_start_callback:
            self.start_button.config(state=tk.DISABLED) # Disable button after starting
            self.solver_start_callback()

    def draw_pegs(self):
        for peg_id, (x, y) in self.peg_coords.items():
            # Draw peg base
            self.canvas.create_rectangle(x - 75, y, x + 75, y + 10, fill="brown")
            # Draw peg rod
            self.canvas.create_rectangle(x - 5, y - 200, x + 5, y, fill="gray")
            # Draw peg label
            self.canvas.create_text(x, y + 25, text=str(peg_id), font=("Arial", 16, "bold"))

    def draw_initial_disks(self):
        initial_state = self.game_logic.get_state()
        for i, disk_size in enumerate(initial_state[0]):
            rect_id = self.canvas.create_rectangle(0, 0, 0, 0, fill="blue")
            text_id = self.canvas.create_text(0, 0, text=str(disk_size), fill="white", font=("Arial", 12, "bold"))
            self.disks[disk_size] = (rect_id, text_id)
            self.update_disk_position(disk_size, 0, i)

    def update_disk_position(self, disk_size, peg_id, disk_index):
        x, y = self.peg_coords[peg_id]
        width = disk_size * self.disk_width_unit
        x1 = x - width / 2
        y1 = y - (disk_index + 1) * self.disk_height
        x2 = x + width / 2
        y2 = y - disk_index * self.disk_height

        rect_id, text_id = self.disks[disk_size]
        self.canvas.coords(rect_id, x1, y1, x2, y2)
        self.canvas.coords(text_id, x1 + width / 2, y1 + self.disk_height / 2)

    def animate_move(self, disk_size, start_peg_id, end_peg_id):
        rect_id, text_id = self.disks[disk_size]
        start_x, start_y_base = self.peg_coords[start_peg_id]
        end_x, end_y_base = self.peg_coords[end_peg_id]

        # Current position of the disk on the canvas
        current_x1, current_y1, current_x2, current_y2 = self.canvas.coords(rect_id)
        current_x = (current_x1 + current_x2) / 2
        current_y = (current_y1 + current_y2) / 2

        # 1. Move up to a clear height
        target_y_up = 100 # A fixed height above all pegs
        steps = 20
        for i in range(steps):
            y_interp = current_y - (current_y - target_y_up) * (i + 1) / steps
            self.canvas.coords(rect_id, current_x1, y_interp - self.disk_height/2, current_x2, y_interp + self.disk_height/2)
            self.canvas.coords(text_id, current_x, y_interp)
            self.update_idletasks()
            time.sleep(0.02)

        # Update current_y after moving up
        _, current_y1, _, current_y2 = self.canvas.coords(rect_id)
        current_y = (current_y1 + current_y2) / 2

        # 2. Move horizontally to the target peg
        target_x = end_x
        start_x_horiz = current_x
        for i in range(steps):
            x_interp = start_x_horiz + (target_x - start_x_horiz) * (i + 1) / steps
            width = disk_size * self.disk_width_unit
            self.canvas.coords(rect_id, x_interp - width/2, current_y1, x_interp + width/2, current_y2)
            self.canvas.coords(text_id, x_interp, current_y)
            self.update_idletasks()
            time.sleep(0.02)

        # 3. Move down to the correct position on the target peg
        # Calculate final y position based on the number of disks already on the target peg
        disks_on_target_peg = len(self.game_logic.pegs[end_peg_id])
        final_y = end_y_base - disks_on_target_peg * self.disk_height # This is the bottom of the disk

        _, current_y1, _, current_y2 = self.canvas.coords(rect_id)
        current_y = (current_y1 + current_y2) / 2

        for i in range(steps):
            y_interp = current_y + (final_y - current_y) * (i + 1) / steps
            self.canvas.coords(rect_id, self.canvas.coords(rect_id)[0], y_interp - self.disk_height/2, self.canvas.coords(rect_id)[2], y_interp + self.disk_height/2)
            self.canvas.coords(text_id, self.canvas.coords(text_id)[0], y_interp)
            self.update_idletasks()
            time.sleep(0.02)

        # Ensure final position is exact
        self.update_disk_position(disk_size, end_peg_id, disks_on_target_peg - 1)

    def on_game_move(self, source_peg, destination_peg):
        # Get the disk that was moved (it\\\\'s the top one from the source peg before the move)
        # Note: This callback is triggered AFTER the game_logic has moved the disk.
        # So, we need to infer the disk_size based on the current state of the destination peg.
        moved_disk_size = self.game_logic.pegs[destination_peg][-1]
        self.animate_move(moved_disk_size, source_peg, destination_peg)
        self.display_error("") # Clear any previous error message

    def display_error(self, message):
        self.error_label.config(text=message)

    def run(self):
        self.mainloop()


