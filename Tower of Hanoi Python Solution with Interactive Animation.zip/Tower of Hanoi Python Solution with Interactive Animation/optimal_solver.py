def get_optimal_moves(n, source, destination, auxiliary):
    """
    Generates the sequence of optimal moves to solve the Tower of Hanoi problem.
    Returns a list of tuples: [(source_peg, destination_peg), ...]
    """
    moves = []
    if n == 1:
        moves.append((source, destination))
        return moves
    moves.extend(get_optimal_moves(n - 1, source, auxiliary, destination))
    moves.append((source, destination))
    moves.extend(get_optimal_moves(n - 1, auxiliary, destination, source))
    return moves


