import unittest
from hanoi_game import TowerOfHanoi
from hanoi_exceptions import IllegalMoveError, SuboptimalMoveError, PuzzleNotCompletedError
from hanoi_solver import solve_hanoi

class TestTowerOfHanoi(unittest.TestCase):
    def test_initialization(self):
        game = TowerOfHanoi(3)
        self.assertEqual(game.get_state(), {0: [3, 2, 1], 1: [], 2: []})

    def test_invalid_peg_index(self):
        game = TowerOfHanoi(3)
        with self.assertRaisesRegex(IllegalMoveError, "Invalid peg index."):
            game.move_disk(0, 3) # Invalid destination peg

    def test_same_source_destination(self):
        game = TowerOfHanoi(3)
        with self.assertRaisesRegex(IllegalMoveError, "Source and destination pegs cannot be the same."):
            game.move_disk(0, 0)

    def test_empty_source_peg(self):
        game = TowerOfHanoi(3)
        with self.assertRaisesRegex(IllegalMoveError, "Source peg is empty."):
            game.move_disk(1, 0) # Peg 1 is empty

    def test_valid_move(self):
        game = TowerOfHanoi(3)
        game.move_disk(0, 2)
        self.assertEqual(game.get_state(), {0: [3, 2], 1: [], 2: [1]})

    def test_invalid_move_larger_on_smaller(self):
        game = TowerOfHanoi(3)
        game.move_disk(0, 2) # Move 1 to peg 2
        game.move_disk(0, 1) # Move 2 to peg 1
        with self.assertRaisesRegex(IllegalMoveError, "Cannot place disk 3 on a smaller disk 2."):
            game.move_disk(0, 1) # Try to move 3 on top of 2

    def test_suboptimal_move_detection(self):
        game = TowerOfHanoi(3)
        # The first optimal move for 3 disks is (0, 2)
        # If we try to move (0, 1) instead, it should be flagged as suboptimal
        with self.assertRaisesRegex(SuboptimalMoveError, "Suboptimal move"):
            game.move_disk(0, 1)

    def test_listener_callback(self):
        game = TowerOfHanoi(3)
        self.called = False
        def listener(src, dest):
            self.called = True
            self.assertEqual(src, 0)
            self.assertEqual(dest, 2)
        game.add_move_listener(listener)
        game.move_disk(0, 2)
        self.assertTrue(self.called)

    def test_legal_but_suboptimal_move_5_disks(self):
        game = TowerOfHanoi(5)
        # The first optimal move for 5 disks is (0, 2)
        # Moving smallest disk (1) from peg 0 to peg 1 is legal but suboptimal
        with self.assertRaisesRegex(SuboptimalMoveError, "Suboptimal move"):
            game.move_disk(0, 1)

    def test_puzzle_not_completed_error(self):
        num_disks = 3
        game = TowerOfHanoi(num_disks)

        # Define a mock solver_move_callback that only performs one move
        def mock_solver_move_callback(source_peg, destination_peg):
            game.move_disk(source_peg, destination_peg)

        # Simulate a solver that only makes one move and then stops
        def incomplete_solver(n, source, destination, auxiliary, move_callback):
            move_callback(source, destination) # Only one move

        # This function simulates the run_solver logic from main.py
        def run_test_solver():
            try:
                incomplete_solver(num_disks, 0, 2, 1, mock_solver_move_callback)
                if not game.is_solved():
                    raise PuzzleNotCompletedError("Solver finished, but the puzzle is not completed.")
            except (IllegalMoveError, SuboptimalMoveError) as e:
                raise e # Re-raise these exceptions to ensure they are caught by the test

        with self.assertRaisesRegex(PuzzleNotCompletedError, "Solver finished, but the puzzle is not completed."):
            run_test_solver()

if __name__ == '__main__':
    unittest.main()


